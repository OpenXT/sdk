XENCLIENT XT UI JAVASCRIPT EXTENSIONS

WARNING:
Functional plugin extensions exist for development purposes only and are an unsupported feature.
We cannot guarantee that your plugins will work in future releases and any resulting composed user interface is not supported.

EXAMPLES:
This zip file contains an example plugin. The contents of this file should be extracted into /usr/lib/xui/plugins/. Upon a refresh of the UI, the examples should be visible in the UI.

The XenClient XT UI is written using the Dojo framework, version 1.7.2. The version of the framework installed is a custom build using only the parts required by the UI, but this does include much of the core dojo and dijit libraries. Dojox is not included. http://dojotoolkit.org/reference-guide/1.7/index.html is a good starting point for documentation relating to the dojo toolkit. The dojo toolkit includes an Asynchronous Module Definition (AMD) library so this is how the examples have been written.

MODELS
The UI has JavaScript models representing objects such as VMs and the Host. These can be accessed using:
XUICache.VMs - object containing XenClient.UI.VMModels representing 'user VMs' accessed via the vm_path property
XUICache.ServiceVMs - object containing XenClient.UI.VMModels representing 'service VMs' accessed via the vm_path property
XUICache.Host - XenClient.UI.HostModel containing properties and methods relating to the host.

These can be found in /usr/lib/xui/script/models

PUBLISH/SUBSCRIBE
dojo/_base/connect is used to provide publish/subscribe functionality. There is an example of subscribing to VM events in the supplied files.

XENCLIENT XT UI WIDGETS AND MIXINS
As well as the Dojo and Dijit namespaces, there are widgets in citrix/common and citrix/xenclient namespaces which can be reused. The example makes use of:
citrix/common/_BoundContainerMixin - if you wish to reuse functionality for binding to widgets
citrix/common/BoundWidget - a simple text widget, which can be bound to a value and given a mask and a map to get the display required
citrix/common/Repeater - when given an array of objects it will display data from each of them based on a template.
citrix/common/MenuBarItem - this is the widget used to provide buttons in the toolbar along the top of the UI.

The dojo, dijit and citrix compiled javascript is located at:
/usr/lib/xui/lib/citrix/xenclient.js
/usr/lib/xui/lib/dojo/dojo.js

DEVELOPMENT
The recommended method of developing is to use an external webkit browser, in particular chromium (version 18 only) because of the tools it has available. We very rarely encounter differences between chromium and the midori webkit browser installed in the UIVM. To allow an external browser:
- edit /etc/rpc-proxy.rules to allow all, and reboot
- run "v4vproxy -p 80 -p -8080" from a command line in dom0 to allow incoming http and websocket connections
- to load the UI goto the following address in a browser: http://<machinename or ip>


