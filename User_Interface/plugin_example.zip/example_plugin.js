require([
    "dijit",
    "dojo/query",
    "dojo/dom-construct",
    "dojo/on",
    "plugins/example/ExamplePane",
    "citrix/common/MenuBarItem"
], function(dijit, query, domConstruct, on, examplePane, menuBarItem) {
    // add a stylesheet
    domConstruct.create("link", {href:'/plugins/example/themes/tundra.css', type:'text/css', rel:'stylesheet'}, document.getElementsByTagName('head')[0]);

    // EXAMPLE 1 - using a new templated widget plugins/example/ExamplePane
    // find the parent node
    var parentNode = query("div.dijitContentPane[region=center]")[0];

    // create the node we want to sit the widget in
    var widgetNode = domConstruct.create("div", null, parentNode);

    // create an instance of our example content pane widget
    var pane = new examplePane({}, widgetNode);

    // EXAMPLE 2 - programmatic creation of existing widgets
    // create a new MenuBarItem
    var menuWidget = new menuBarItem({class: "left", iconClass: "menuIcon menuIconExample", splitter: "right", label: "Example"});

    // add a dijit onClick event handler
    var handler = on(menuWidget, "click", function(event) {
        XUICache.messageBox.showInformation("Example button clicked!");
    });
    // handler.remove() will remove the event handler from the object, if required

    // find the parent widget (one which is a container) and add the new menu widget to its children collection
    dijit.byId("frameHeader").addChild(menuWidget);
});