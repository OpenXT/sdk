define([
    "dojo/_base/declare",
    "dojo/_base/array",
    "dojo/_base/connect",
    "dojo/_base/lang",
    // resources
    "dojo/text!plugins/example/templates/ExamplePane.html",
    // mixins
    "dijit/_Widget",
    "dijit/_Templated",
    "citrix/common/_BoundContainerMixin",
    // used in template
    "citrix/common/BoundWidget",
    "citrix/common/Repeater"
],
function(declare, array, connect, lang, template, _widget, _templated, _boundContainerMixin) {
return declare("plugins.example.ExamplePane", [_widget, _templated, _boundContainerMixin], {

    // set the html template, listed in the define requirements above
    templateString: template,
    // tell the dojo parser that there are widgets within this widget's template
    widgetsInTemplate: true,

    postCreate: function() {
        // run base postCreate function(s)
        this.inherited(arguments);

        this.startup();

        this.subscribe(XUtils.publishTopic, this._messageHandler);

        this._createSubscriptions();
        this._bindDijit();
    },

    _bindDijit: function() {
        this.inherited(arguments);
        var vms = [];
        for(var vm in XUICache.VMs) {
            vms.push(XUICache.VMs[vm]);
        }
        this.bind({VMs: vms, vmCount: XUICache.getVMCount()});
    },

    _createSubscriptions: function() {
        array.forEach(this._vmHandles, function(handle) {
            connect.unsubscribe(handle);
        });
        this._vmHandles = [];
        for(var vm in XUICache.VMs) {
            this._vmHandles.push(connect.subscribe(XUICache.VMs[vm].publish_topic, lang.hitch(this, this._messageHandler)));
        }
    },

    _messageHandler: function(message) {
        switch(message.type) {
            case XenConstants.TopicTypes.MODEL_CHANGED: {
                this._bindDijit();
                break;
            }
            case XenConstants.TopicTypes.UI_VM_CREATED:
            case XenConstants.TopicTypes.UI_VM_DELETED: {
                this._createSubscriptions();
                this._bindDijit();
                break;
            }
        }
    }
});
});